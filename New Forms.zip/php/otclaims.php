<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1" charset="UTF-8">
    <title>Claim For Overtime</title>
    <style>
    .contain {
        max-width: 1170px;
        height: 297mm;
        width: 210mm;
        padding: 1em;
        margin: auto;
        border: 1px solid black;
        padding: 10px;
    }

    div {
        font-family: Roboto, 'Segoe UI', Tahoma, sans-serif;
        font-size: 77.25%;
    }

    .full-width {
        grid-column: 1 / 3;
    }

    form {
        display: grid;
        grid-template-columns: 1fr 1fr;
        grid-gap: 1px;
        margin-top: 0.5cm;
        margin-bottom: 2.54cm;
        margin-right: 0.1cm;
        margin-left: 0.1cm;

    }

    input,
    textarea {
        width: 90%;
        border: 0.1px solid #000;
    }

    form label {
        display: block;
    }

    form p {
        margin: 0;
    }

    /** text area space */
    input,
    textarea {
        padding: 0.2em;
    }

    output {
        border: 1px solid #000;
        padding: 0.09em;
    }

    table {
        border-collapse: collapse;
    }

    td {
        height: 15px;
    }

    body {
        font-family: Roboto, 'Segoe UI', Tahoma, sans-serif;
        font-size: 81.25%;
    }

    td,
    th {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 8px;
    }

    h2 {
        text-decoration: underline;
    }
    </style>
</head>

<body>
    <div class="contain">
        <div class="form">
            <h2>
                <center>CLAIM FOR OVERTIME WORK</center>
            </h2>
            <form action="/action_page.php" novalidate>
                <P>
                    <label for="name">Name of claimant: </label>
                    <input type="text" id="fname" name="fname">
                </P>

                <p>
                    <label for="number">Personnel Number:</label>
                    <input type="text" id="num" name="num">
                </p>

                <p>
                    <label for="dept">Department:</label>
                    <input type="text" id="deptmnt" name="deptmnt">
                </p>

                <P>
                <label for="dte">Date:</label>
                <input type="date" id="dte" name="dte">
                </P>

                <p>
                <label for="dtefrom">Claim from date:</label>
                <input type="date" id="dtefrom" name="dtefrom">
                </p>

                <P>
                <label for="dtefrom">Claim to date:</label>
                <input type="date" id="dteto" name="dteto">
                </P>
                <p><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br></p>
                <p><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br></p>
                <p>
                <label for="ot">REASON FOR OVERTIME:</label>
                <textarea name="comment" rows="5" cols="40"></textarea>
                </p>

                <P>

                </P>

                <p>
                <label for="sign">Claimant's Signature:</label>
                <input type="text" id="sign" name="sign">
                </p>
                
                <p>
                <label for="dateee">Date:</label>
                <input type="date" id="dateee" name="dateee">
                </p>
                
                <p>
                <label for="sign">Signature of Supervisor:</label>
                <input type="text" id="sign" name="sign">
                </p>

                <p>
                <label for="dateee">Date:</label>
                <input type="date" id="dateee" name="dateee">
                </p>

                <p>
                <label for="sign">Signature - HOD/Line Manager:</label>
                <input type="text" id="sign" name="sign">
                </p>

                <p>
                <label for="dateee">Date:</label>
                <input type="date" id="dateee" name="dateee">
                </p>

                <p>
                <label for="sign">Approved -Payroll Officer:</label>
                <input type="text" id="sign" name="sign">
                </p>

                <p>
                <label for="dateee">Date:</label>
                <input type="date" id="dateee" name="dateee">
                </p>
                
        </div>
    </div>
</body>

</html>