<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="viewport" 
    content="width=device-width, initial-scale=1" charset="UTF-8">
    <title>Advice Form</title>
    <style>
    * {
        box-sizing: border-box;
    }
    body {
        background: grey;
        height: 100%;
        width: 230mm;
        margin: 0 auto;
        padding: 0;
    }

    .contain {
        width: 210mm;
        height: 297mm;
        margin: 0 auto;
        background: white;
        padding: 0;
    }

    div {
        font-family: Roboto, 'Segoe UI', Tahoma, sans-serif;
        background: white;
    }

    h1 {
        font-size: 100.25%;
    }

    h3 {
        margin: 0;
        margin-bottom: 1rem;
        font-size: 90.25%;
    }

   /** text area space */
    input,
    textarea {
        width: 90%;
        margin-bottom: 1px;
        font-family: 'Gill Sans', 'Gill Sans MT', 
        Calibri, 'Trebuchet MS', sans-serif;
        background: rgba(255,255,255,.1);
        border: none;
        border-radius: 4px;
        font-size: 15px;
        margin: 0;
        outline: 0;
        padding: 7.5px;
        box-sizing: border-box; 
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box; 
        background-color: #e8eeef;
        color:#8a97a0;
    }

    form {
        display: grid;
        grid-template-columns: 1fr 1fr;
        grid-gap: 1px;
        margin-top: 0.5cm;
        margin-bottom: 2.54cm;
        margin-right: 0.1cm;
        margin-left: 0.1cm;

        padding: 10px 20px;
        
        margin: 10px auto;
        padding: 20px;
        border-radius: 8px;
        font-family: 'Gill Sans', 'Gill Sans MT', 
        Calibri, 'Trebuchet MS', sans-serif;
        font-size: 80%;
    }

    .submitbutton {
        grid-column: 1 / span 2;;
    }

    form label {
        display: block;
        margin-bottom: 2.5px;
    }

    form p {
        margin-bottom: 1px;
    }

    output{
        border: 1px solid #000;
        padding: 0.09em;
    }

    .Submit {
        background: lightgrey;
        width: 200%;
        border: 0;
    }

    @media print {
    html, body {
        width: 210mm;
        height: 297mm;
        -webkit-print-color-adjust: exact; 
  }
}


    </style>
</head>
<body>
    <?php
     /**
      * Php version 8
      *
      * @category Description
      * @package  PHP
      * @author   Vilho Nguno <vilhonguno@gmail.com>
      * @license  http://localhost:4000/php/adviceform.php Advice Form
      * @link     http://localhost:4000/php/adviceform.php
      * Define variables and set to empty values 
      */
    $adviceNR = $persNum = $persMember = $dateOfImple = $salaryNPA 
        = $salaryTCOE = $housingAllow = $rentalAllow = $identification 
            = $decuctions = $amount1 = $amount2 = $leaveCredit = $proData 
                = $DOB = $deductDebt = $otherSpecify = $date1 = $date2 = $date3 
                    = $date4 = $compiledBy = $approvedBy = $compiledBy2 
                        = $approvedBy2 = $PSBA = $PSF = $HRA = $MF
                            = $SSF = $PF = $PBF = $RL = $BS38 =$TCOE
                                = $HD = $UL = $Os = "";

    
    $persMember = test_input($_POST["persMember"]);
    $persNum = test_input($_POST["persNum"]);
    $adviceNR = test_input($_POST["adviceNR"]);
    $dateOfImple = test_input($_POST["dateOfImple"]);
    $salaryNPA = test_input($_POST["salaryNPA"]);

    $salaryTCOE = test_input($_POST["salaryTCOE"]);
    $housingAllow = test_input($_POST["housingAllow"]);
    $rentalAllow = test_input($_POST["rentalAllow"]);
    $identification = test_input($_POST["identification"]);

    $decuctions = test_input($_POST["decuctions"]);
    $amount1 = test_input($_POST["amount1"]);
    $amount2 = test_input($_POST["amount2"]);
    $leaveCredit = test_input($_POST["leaveCredit"]);
    $proData = test_input($_POST["proData"]);

    $DOB = test_input($_POST["DOB"]);
    $deductDebt = test_input($_POST["deductDebt"]);
    $otherSpecify = test_input($_POST["otherSpecify"]);
    $date1 = test_input($_POST["date1"]);
    $date2 = test_input($_POST["date2"]);
    $date3 = test_input($_POST["date3"]);

    $date4 = test_input($_POST["date4"]);
    $compiledBy = test_input($_POST["compiledBy"]);
    $approvedBy = test_input($_POST["approvedBy"]);
    $compiledBy2 = test_input($_POST["compiledBy2"]);
    $approvedBy2 = test_input($_POST["approvedBy2"]);

     

    $PSBA = test_input($_POST['PSBA']);
    $P2F = test_input($_POST["P2F"]);
    $HRA = test_input($_POST["HRA"]);
    $MF = test_input($_POST["MF"]);
    $SSF = test_input($_POST["SSF"]);
    $PF = test_input($_POST["PF"]);
    $PBF = test_input($_POST["PBF"]);
    $RL = test_input($_POST["RL"]);

    $BS38 = test_input($_POST["BS38"]);
    $TCOE = test_input($_POST["TCOE"]);

    $HD = test_input($_POST["HD"]);
    $UL = test_input($_POST["UL"]);
    $Os = test_input($_POST["Os"]);
    /**  
     * <?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>
     */
    /**
     * Undocumented function
     *
     * @param string $data yes
     * 
     * @return string
     */
    function Test_input($data) 
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
    ?>

    <div class="contain">
        <div class="form">
            <img src="logo.jpg" alt="NUST HEADER" 
            style = "width:770px; 
                    height:100px";> 
            <h1>
                <center>NOTICE OF APPOINTMENT/AMENDMENTS/RESIGNATION</center>
            </h1>
            <form method="post" action="af2.php">
                <P>
                    <label for="">Advice Number</label>
                    <input type="text" name="adviceNR">
                </P>
                <P></P>
                <p>
                    <label for="">Personnel Member</label>
                    <input type="text" name="persMember">
                </p>
                <p>
                    <label for="">Personnel Number</label>
                    <input type="text" name="persNum">
                </p>
                <p>
                    <label for="">Date of Implementation</label>
                    <input type="date" name="dateOfImple">
                    <br><br>
                </p>
                <p>
                <h3>APPOINTMENTS/AMENDMENTS:</h3> <br>
                <label for=""> ADDENDUMS: </label>
                </p>
                <label>
                    Applicant to pay salary into Bank Account
                    <input type="checkbox" name = "PSBA" value="1"> 
                </label>
                <label>
                    PAYE 2 Form
                    <input type="checkbox"name = "P2F" value="Provided">
                </label>
                <label>
                    Housing/Rental Agreement
                    <input type="checkbox"
                    name = "HRA" value="Provided">
                </label>
                <label>
                    Medical Form
                    <input type="checkbox"
                    name = "MF" value="Provided">
                </label>
                <label>
                    Social Security Form
                    <input type="checkbox"
                    name = "SSF" value="Provided">
                </label>
                <label>
                    Pension Form
                    <input type="checkbox"
                    name = "PF" value="Provided">
                </label>
                <label>
                    Payment for Benefits Form
                    <input type="checkbox"
                    name = "PBF" value="Provided">
                </label>
                <label>
                    Resignation Letter
                    <input type="checkbox"
                    name = "RL" value="Provided">
                </label>

                <p>
                    <label for="">Salary Notch Per Annum</label>
                    <input type="text" name="salaryNPA">
                </p>
                <p>
                    <label for="">Salary TCOE</label>
                    <input type="text" name="salaryTCOE">
                </p>
                <p>
                    <label for="">Housing Allowance</label>
                    <input type="text" name="housingAllow">
                </p>
                <p>
                    <label for="">Rental Allowance</label>
                    <input type="text" name="rentalAllow">
                </p>
                <p></p>
                <p></p>

                    <label>
                        38% of Basic Salary
                        <input type="checkbox"
                        name = "BS38" value="Yes">
                    </label>
                    <label>
                        TCOE
                        <input type="checkbox"
                        name = "TCOE" value="Yes">
                    </label>
                
                <p> </p>
                <p>
                <h4>Allowances </h4>
                </p>
                <p>
                    <label for="">Identification</label>
                    <input type="text" name=identification>
                </p>
                <p>
                    <label for="">Amount</label>
                    <input type="text" name="amount1">
                </p>
                <p>
                    <label for="">Deductions</label>
                    <input type="text" name=decuctions>
                </p>
                <p>
                    <label for="">Amount</label>
                    <input type="text" name="amount2">
                </p>
                <p> </p>
                <p>
                <h4>RESIGNATION</h4> <br>
                </p>
                <p> </p>
                <p>
                    <label for="">DOB</label>
                    <input type="date" name="DOB">
                </p>
                <p>
                    <label for="">Leave Credit: Day(s)</label>
                    <input type="text" name="leaveCredit">
                </p>
                <p>
                    <label for="">Pro-rata bonus: Day(s)</label>
                    <input type="text" name="proData">
                </p>
                
                <p>
                    <label for="">Deduction(s) regarding departmental debt: </label>
                    <input type="text" name="deductDebt">
                </p>
                <p> </p>
                <p> </p>
                    <label>
                        Housing Deduction
                        <input type="checkbox"
                        name = "HD" value="Yes">
                    </label>
                    <label>
                        Unpaid Leave
                        <input type="checkbox"
                        name = "UL" value="Yes">
                    </label>
                    <label>
                        Other (specify)
                        <input type="checkbox"
                        name = "Os" value="Yes">
                        <input type="text" name="otherSpecify">
                    </label>
            
                <p> </p>
                <p><br></p>
                <p>
                <h3>HUMAN RESOURCES DEPARTMENT</h3> 
                </p>
                <p>
                    <label for="">Compiled By:</label>
                    <input type="text" name="compiledBy">

                    <label for="">Approved By:</label>
                    <input type="text" name="approvedBy">
                </p>
                <p>
                    <label for="">Date:</label>
                    <input type="date" name="date1">

                    <label for="">Date:</label>
                    <input type="date" name="date2">
                </p>
                <h3>FINANCE DEPARTMENT</h3>
                </p>
                <p>
                    <label for="">Compiled By:</label>
                    <input type="text" name="compiledBy2">

                    <label for="">Approved By:</label>
                    <input type="text" name="approvedBy2">
                </p>
                <p>
                    <label for="">Date:</label>
                    <input type="date" name="date3">

                    <label for="">Date:</label>
                    <input type="date" name="date4">
                </p>
                <p> </p>
                    <input class= "submitbutton" type="submit" 
                    name="submit" value="Submit">
                    
            </form>
        </div>
    </div>
</body>
</html>