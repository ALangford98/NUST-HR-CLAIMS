<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1" 
    charset="UTF-8">
    <title>Claim For Overtime</title>
    <style>
    * {
        box-sizing: border-box;
    }
    body {
        background: grey;
        height: 100%;
        width: 230mm;
        margin: 0 auto;
        padding: 0;
    }

    .contain {
        width: 210mm;
        height: 297mm;
        margin: 0 auto;
        background: white;
        padding: 0;
    }

    div {
        font-family: Roboto, 'Segoe UI', Tahoma, sans-serif;
        background: white;
    }

    h1 {
        font-size: 100.25%;
    }

    h3 {
        margin: 0;
        margin-bottom: 1rem;
        font-size: 90.25%;
    }

   /** text area space */
    input,
    textarea {
        width: 90%;
        margin-bottom: 1px;
        font-family: 'Gill Sans', 'Gill Sans MT', 
        Calibri, 'Trebuchet MS', sans-serif;
        background: rgba(255,255,255,.1);
        border: none;
        border-radius: 4px;
        font-size: 15px;
        margin: 0;
        outline: 0;
        padding: 7.5px;
        box-sizing: border-box; 
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box; 
        background-color: #e8eeef;
        color:#8a97a0;
    }

    form {
        display: grid;
        grid-template-columns: 1fr 1fr;
        grid-gap: 1px;
        margin-top: 0.5cm;
        margin-bottom: 2.54cm;
        margin-right: 0.1cm;
        margin-left: 0.1cm;

        padding: 10px 20px;
        
        margin: 10px auto;
        padding: 20px;
        border-radius: 8px;
        font-family: 'Gill Sans', 'Gill Sans MT', 
        Calibri, 'Trebuchet MS', sans-serif;
        font-size: 80%;
    }

    .submitbutton {
        grid-column: 1 / span 2;;
    }

    form label {
        display: block;
        margin-bottom: 2.5px;
    }

    form p {
        margin-bottom: 1px;
    }

    output{
        border: 1px solid #000;
        padding: 0.09em;
    }

    .Submit {
        background: lightgrey;
        width: 200%;
        border: 0;
    }

    @media print {
    html, body {
        width: 210mm;
        height: 297mm;
        -webkit-print-color-adjust: exact; 
  }
}
    td,
    th {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 8px;
    }

    </style>
</head>

<body>
<?php
    /**
     * Php version 8
     *
     * @category Description
     * @package  PHP
     * @author   Vilho Nguno <vilhonguno@gmail.com>
     * @license  http://localhost:4000/php/adviceform.php Advice Form
     * @link     http://localhost:4000/php/adviceform.php
     * Define variables and set to empty values 
     */
    $date = $date1 = $date2 = $date3 = $date4 ="";

    

    $date1 = test_input($_POST["date"]);
    $date1 = test_input($_POST["date1"]);
    $date2 = test_input($_POST["date2"]);
    $date3 = test_input($_POST["date3"]);
    $date4 = test_input($_POST["date4"]);

    /**
     * Undocumented function
     *
     * @param string $data yes
     * 
     * @return string
     */
function Test_input($data) 
{
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
}
?>
    <div class="contain">
        <div class="form">
        <img src="logo.jpg" alt="NUST HEADER" 
            style = "width:770px; 
                    height:100px";> 
            <h1>
                <center>CLAIM FOR OVERTIME WORK</center>
            </h1>
            <form method="post" action="otclaims2.php">
                <P>
                    <label for="name">Name of claimant: </label>
                    <input type="text" id="fname" name="fname">
                </P>

                <p>
                    <label for="number">Personnel Number:</label>
                    <input type="text" id="num" name="num">
                </p>

                <p>
                    <label for="dept">Department:</label>
                    <input type="text" id="deptmnt" name="deptmnt">
                </p>

                <P>
                <label for="dte">Date:</label>
                <input type="date" id="dte" name="dte">
                </P>

                <p>
                <label for="dtefrom">Claim from date:</label>
                <input type="date" id="dtefrom" name="dtefrom">
                </p>

                <P>
                <label for="dtefrom">Claim to date:</label>
                <input type="date" id="dteto" name="dteto">
                </P>

                <p>
                <label for="ot">REASON FOR OVERTIME:</label>
                <textarea name="comment" rows="5" cols="40"></textarea>
                </p>

                <P>

                </P>

                <p>
                <label for="sign">Claimant's Signature:</label>
                <input type="text" id="sign" name="sign">
                </p>
                
                <p>
                <label for="dateee">Date:</label>
                <input type="date" id="dateee" name="dateee">
                </p>
                
                <p>
                <label for="sign">Signature of Supervisor:</label>
                <input type="text" id="sign" name="sign">
                </p>

                <p>
                <label for="dateee">Date:</label>
                <input type="date" id="dateee" name="dateee">
                </p>

                <p>
                <label for="sign">Signature - HOD/Line Manager:</label>
                <input type="text" id="sign" name="sign">
                </p>

                <p>
                <label for="dateee">Date:</label>
                <input type="date" id="dateee" name="dateee">
                </p>

                <p>
                <label for="sign">Approved -Payroll Officer:</label>
                <input type="text" id="sign" name="sign">
                </p>

                <p>
                <label for="dateee">Date:</label>
                <input type="date" id="dateee" name="dateee">
                </p>
                <p> </p>
                    <input class= "submitbutton" type="submit" 
                    name="submit" value="Submit">
            </form>  
                
        </div>
    </div>
</body>

</html>