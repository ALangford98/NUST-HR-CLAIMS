<!DOCTYPE html PUBLIC "-//W3C//DTD HTML+RDFa 1.1//EN">
<html lang="en" dir="ltr" version="HTML+RDFa 1.1" xmlns:content="http://purl.org/rss/1.0/modules/content/" xmlns:dc="http://purl.org/dc/terms/" xmlns:foaf="http://xmlns.com/foaf/0.1/" xmlns:og="http://ogp.me/ns#" xmlns:rdfs="http://www.w3.org/2000/01/rdf-schema#" xmlns:sioc="http://rdfs.org/sioc/ns#" xmlns:sioct="http://rdfs.org/sioc/types#" xmlns:skos="http://www.w3.org/2004/02/skos/core#" xmlns:xsd="http://www.w3.org/2001/XMLSchema#">


<!-- Mirrored from my.nust.na/ by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 10 Oct 2021 02:49:15 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head profile="http://www.w3.org/1999/xhtml/vocab">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no" />
  
  <link rel="shortcut icon" href="outside/sites/default/files/icon.png" type="image/png" />
  
  <title>NUST Forms</title>
  
  <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="outside/css/style-5.css" type="text/css" media="all" />
    <link rel="stylesheet" href="style.css" type="text/css" media="all" />
    
    <link rel="stylesheet" href="outside/sites/all/modules/ckeditor/css/ckeditor.css" type="text/css" media="all" />
    
    <link rel="stylesheet" href="outside/css/style-3.css" type="text/css" media="all" />
    
    <link type="text/css" rel="stylesheet" href="outside/ajax/libs/font-awesome/4-4-0/css/font-awesome.min.css" media="all" />
    
    <link rel="stylesheet" href="outside/css/style-2.css" type="text/css" media="all" />
    
    <link rel="stylesheet" href="outside/css/style.css" type="text/css" media="all" />
    
    <link rel="stylesheet" href="outside/css/style-6.css" type="text/css" media="all" />
    
    <!-- Custom CSS -->
    <link href="assets/libs/fullcalendar/dist/fullcalendar.min.css" rel="stylesheet" />
    <link href="assets/extra-libs/calendar/calendar.css" rel="stylesheet" />
  
  <!--[if gte IE 9]><!-->
  <link rel="stylesheet" href="outside/css/style-7.css" type="text/css" media="all and (min-width: 740px) and (min-device-width: 740px), (max-device-width: 800px) and (min-width: 740px) and (orientation:landscape)" />
  <!--<![endif]-->
  
  <!--[if gte IE 9]><!-->
  <link rel="stylesheet" href="outside/css/style-8.css" type="text/css" media="all and (min-width: 980px) and (min-device-width: 980px), all and (max-device-width: 1024px) and (min-width: 1024px) and (orientation:landscape)" />
  <!--<![endif]-->
  
  <!--[if gte IE 9]><!-->
  <link rel="stylesheet" href="outside/css/style-9.css" type="text/css" media="all and (min-width: 1220px)" />
  <!--<![endif]-->
  
</head>

<body class="html front not-logged-in page-node">
  <div class="region region-page-top" id="region-page-top">
    <div class="region-inner region-page-top-inner"> </div>
  </div>
  <div class="page clearfix" id="page">
    <section id="section-content" class="section section-content">
          <div class="container">
            <h2>OVERTIME FORM CATEGORY</h2>
      
            <div class="select-box1">
              <div class="options-container1">
                <div class="option1">
                  <input
                    type="radio"
                    class="radio"
                    id="form1"
                    name="category"
                  />
                  <label for="automobiles"><a href="adviceform.php">>>NOTICE OF APPOINTMENT/AMENDMENTS/RESIGNATION</a></label>
                </div>
      
                <div class="option1">
                  <input type="radio" class="radio" id="film" name="category" />
                  <label for="film"><a href="otclaims.php">>>NUST OVERTIME CLAIM FORM</a></label>
                </div>
      
                <div class="option1">
                  <input type="radio" class="radio" id="science" name="category" />
                  <label for="science"><a href="AcademicStaffClaims.php">>>NUST PART-TIME CLAIM FOR ACADEMIC STAFF</a></label>
                </div>
      
                <div class="option1">
                  <input type="radio" class="radio" id="art" name="category" />
                  <label for="art"><a href="AdminStaffForm.php">>>NUST PART-TIME CLAIM FOR ADMIN STAFF</a></label>
                </div>
      
              </div>
            </div>
          </div>
          <script src="main.js"></script>
    </section>
</body>
</html>
